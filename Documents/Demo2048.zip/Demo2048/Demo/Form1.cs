﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Threading;
using System.Media;
using System.IO;

namespace Demo
{
    public partial class Form1 : Form
    {
        //Khai báo Biến
        private Random rand = new Random();
        private int Score;
        private int HighScore;
        private Label[,] Number = new Label[4, 4]; // mảng ( chuỗi )
        private int[,] Boardsize = new int[4, 4];  // mảng  ( số )
        private int tag = 5;  //Khoảng cách giữa các ô
        StreamReader read = new StreamReader("BestScore.txt"); // Ghi Lại Điểm Cao
        Stack<int[,]> pushnumber = new Stack<int[,]>();
        Stack<int> pushscore = new Stack<int>();
        public Form1()
        {
            InitializeComponent();
        }
        private void LoadGame()
        {
            string HCTemp = read.ReadToEnd();
            read.Close();
            int Temp = Convert.ToInt32(HCTemp);
            lb_HighScore.Text = Temp.ToString();
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Number[i, j] = new Label();
                    Number[i, j].Location = new Point(tag + i * (100 + tag), tag + j * (100 + tag));
                    Number[i, j].Size = new Size(100, 100);
                    Number[i, j].Font = new Font("Product Sans", 25, FontStyle.Bold);
                    Number[i, j].TextAlign = ContentAlignment.MiddleCenter;
                    Number[i, j].BorderStyle = BorderStyle.FixedSingle;
                    Grid.Controls.Add(Number[i, j]);
                }
            }
            Main();
        }
        // Main Game
        public void Main()
        {           
            for (int x = 0; x < 4; x++)
                for (int y = 0; y < 4; y++)
                    Boardsize[x, y] = 0;
            RanDomNumbers();
            RanDomNumbers();
            Score = 0;
            pushnumber = new Stack<int[,]>();
            pushscore = new Stack<int>();
            this.Refresh();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            LoadGame();           
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (Boardsize[i, j] == 0)
                        Number[i, j].Text = "";
                    else
                        Number[i, j].Text = Boardsize[i, j].ToString();
                    SetColor(i, j);
                }
            }
            lb_Score.Text = Score.ToString();           
        }
        //Tạo số vị trí ngẫu nhiên
        private void RanDomNumbers()
        {
            int x, y;
            do
            {
                x = rand.Next(0, 4);
                y = rand.Next(0, 4);
            } while (Boardsize[x, y] != 0);
            Double r = rand.NextDouble();
            Boardsize[x, y] = r > 0.9 ? 4 : 2;
        }
        // Stack để lưu số và điểm
        private void SaveToStack()
        {
            int[,] x = new int[4, 4];
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    x[i, j] = Boardsize[i, j];
            pushnumber.Push(x);
            pushscore.Push(Score);
        }
        public void Check(bool Temp)
        {
            if ((Temp) == true)
            {
                RanDomNumbers();
            }
            else
            {
                pushnumber.Pop();
                pushscore.Pop();
            }
        }
        // Thao tác bàn phím
        private void UP()
        {
            SaveToStack();
            bool Temp = false;
            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 3; y++)
                {
                    for (int y1 = y + 1; y1 < 4; y1++)
                    {
                        if (Boardsize[x, y1] > 0)
                        {
                            if (Boardsize[x, y] == 0)
                            {
                                Boardsize[x, y] = Boardsize[x, y1];
                                Boardsize[x, y1] = 0;
                                y--;
                                Temp = true;
                            }
                            else if (Boardsize[x, y] == Boardsize[x, y1])
                            {
                                Boardsize[x, y] *= 2;
                                Boardsize[x, y1] = 0;
                                Score += Boardsize[x, y];
                                Temp = true;
                            }
                            break;
                        }
                    }
                }
            }
            Check(Temp);
        }
        private void DOWN()
        {
            SaveToStack();
            bool Temp = false;
            for (int x = 0; x < 4; x++)
            {
                for (int y = 3; y >= 1; y--)
                {
                    for (int y1 = y - 1; y1 >= 0; y1--)
                    {
                        if (Boardsize[x, y1] > 0)
                        {
                            if (Boardsize[x, y] == 0)
                            {
                                Boardsize[x, y] = Boardsize[x, y1];
                                Boardsize[x, y1] = 0;
                                y++;
                                Temp = true;
                            }
                            else if (Boardsize[x, y] == Boardsize[x, y1])
                            {
                                Boardsize[x, y] *= 2;
                                Boardsize[x, y1] = 0;
                                Score += Boardsize[x, y];
                                Temp = true;
                            }
                            break;
                        }
                    }
                }
            }
            Check(Temp);
        }
        private void RIGHT()
        {
            SaveToStack();
            bool Temp = false;
            for (int y = 0; y < 4; y++)
            {
                for (int x = 3; x >= 1; x--)
                {
                    for (int x1 = x - 1; x1 >= 0; x1--)
                    {
                        if (Boardsize[x1, y] > 0)
                        {
                            if (Boardsize[x, y] == 0)
                            {
                                Boardsize[x, y] = Boardsize[x1, y];
                                Boardsize[x1, y] = 0;
                                x++;
                                Temp = true;
                            }
                            else if (Boardsize[x, y] == Boardsize[x1, y])
                            {
                                Boardsize[x, y] *= 2;
                                Boardsize[x1, y] = 0;
                                Score += Boardsize[x, y];
                                Temp = true;
                            }
                            break;
                        }
                    }
                }
            }
            Check(Temp);
        }
        private void LEFT()
        {
            SaveToStack();
            bool Temp = false;
            for (int y = 0; y < 4; y++)
            {
                for (int x = 0; x < 3; x++)
                {
                    for (int x1 = x + 1; x1 < 4; x1++)
                    {
                        if (Boardsize[x1, y] > 0)
                        {
                            if (Boardsize[x, y] == 0)
                            {
                                Boardsize[x, y] = Boardsize[x1, y];
                                Boardsize[x1, y] = 0;
                                x--;
                                Temp = true;
                            }
                            else if (Boardsize[x, y] == Boardsize[x1, y])
                            {
                                Boardsize[x, y] *= 2;
                                Boardsize[x1, y] = 0;
                                Score += Boardsize[x, y];
                                Temp = true;
                            }
                            break;
                        }
                    }
                }
            }
            Check(Temp);
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Up)
                UP();
            if (e.KeyData == Keys.Down)
                DOWN();
            if (e.KeyData == Keys.Right)
                RIGHT();
            if (e.KeyData == Keys.Left)
                LEFT();
            this.Refresh();
            if (CheckGameOver() == true)
            {
                DialogResult endgame = MessageBox.Show("Điểm: " + Score.ToString() + "\n" + "Bạn có muốn chơi lại không?",
                "Game Over", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(endgame == DialogResult.Yes)
                {
                    if (Score > Convert.ToInt32(lb_HighScore.Text))
                    {
                        HighScore = Score;
                        lb_HighScore.Text = HighScore.ToString();
                        StreamWriter write = new StreamWriter("BestScore.txt");
                        write.WriteLine(lb_Score.Text);
                        write.Flush();
                        write.Close();
                    }
                    Main();
                }
            }
        }
        // Kiểm tra thắng thua
        private bool CheckGameOver()
        {
            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    if (Boardsize[x, y] == 0 ||
                        (y < 3 && Boardsize[x, y] == Boardsize[x, y + 1]) ||
                        (x < 3 && Boardsize[x, y] == Boardsize[x + 1, y]))
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        // Đặt màu cho số ( 2, 4, 8, 16,...)
        private void SetColor(int x, int y)
        {
            switch (Boardsize[x, y])
            {
                case 0: Number[x, y].BackColor = ColorTranslator.FromHtml("whitesmoke"); break;
                case 2: Number[x, y].BackColor = ColorTranslator.FromHtml("#9999ff"); break;
                case 4: Number[x, y].BackColor = ColorTranslator.FromHtml("#b366ff"); break;
                case 8: Number[x, y].BackColor = ColorTranslator.FromHtml("#B92C92"); break;
                case 16: Number[x, y].BackColor = ColorTranslator.FromHtml("#FFD203"); break;
                case 32: Number[x, y].BackColor = ColorTranslator.FromHtml("#00ABD6"); break;
                case 64: Number[x, y].BackColor = ColorTranslator.FromHtml("#018752"); break;
                case 128: Number[x, y].BackColor = ColorTranslator.FromHtml("#FF6D00"); break;
                case 256: Number[x, y].BackColor = ColorTranslator.FromHtml("#C6D601"); break;
                case 512: Number[x, y].BackColor = ColorTranslator.FromHtml("#00457C"); break;
                case 1024: Number[x, y].BackColor = ColorTranslator.FromHtml("#F3426E"); break;
                case 2048: Number[x, y].BackColor = ColorTranslator.FromHtml("#00e6e6"); break;
                case 4096: Number[x, y].BackColor = ColorTranslator.FromHtml("#5C707B"); break;
                case 8192: Number[x, y].BackColor = ColorTranslator.FromHtml("#42B5A6"); break;
            }
        }
        // NewGame và Undo Click
        private void NewGame_Click(object sender, EventArgs e)
        {
            if (Score > Convert.ToInt32(lb_HighScore.Text))
            {
                HighScore = Score;
                lb_HighScore.Text = HighScore.ToString();
                StreamWriter write = new StreamWriter("BestScore.txt");
                write.WriteLine(lb_Score.Text);
                write.Flush();
                write.Close();
            }
            Main();
        }
        private void Undo_Click(object sender, EventArgs e)
        {
            if (pushnumber.Count > 0)
            {
                int[,] x = new int[4, 4];
                x = pushnumber.Pop();
                Score = pushscore.Pop();
                for (int i = 0; i < 4; i++)
                    for (int j = 0; j < 4; j++)
                        Boardsize[i, j] = x[i, j];
                lb_Score.Text = Score.ToString();
                this.Refresh();
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult endgame = MessageBox.Show("Thoát Game !",
                "Close Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (endgame == DialogResult.No)
                e.Cancel = true;
            else
                e.Cancel = false;
        }
    }
}
